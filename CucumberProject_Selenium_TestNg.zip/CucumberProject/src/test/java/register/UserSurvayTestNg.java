package register;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import webPageDriver.WebPageDriver;

public class UserSurvayTestNg extends WebPageDriver {

   // @Test
    public void getPageTitle() {
        driver.get("http://google.com");
        System.out.println(driver.getTitle());
    }

}
