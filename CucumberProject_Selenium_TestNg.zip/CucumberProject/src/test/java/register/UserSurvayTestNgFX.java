package register;


import org.testng.annotations.Test;
import webPageDriver.WebPageDriver;

public class UserSurvayTestNgFX extends WebPageDriver {

    //@Test
    public void getYitle() {
        driver.get("http://baidu.com");
        System.out.println(driver.getCurrentUrl());
    }
}
