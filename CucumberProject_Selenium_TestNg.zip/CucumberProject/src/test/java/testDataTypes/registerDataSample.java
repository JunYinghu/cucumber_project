package testDataTypes;

public class registerDataSample {

        public String userName;
        public String emailAdd;
        public String confirmEmailAddr;
        public String passwordWord;
        public String confirmPassword;
        public String ourCompanyName;
        public String timeZone;
        public String company;
}
