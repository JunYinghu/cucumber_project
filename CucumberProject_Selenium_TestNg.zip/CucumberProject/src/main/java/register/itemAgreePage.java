package register;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class itemAgreePage {
    private WebDriver driver;
    itemAgreePageLocator itemAgreePageLocator;


    public itemAgreePage(WebDriver driver){
        this.driver =driver;
        itemAgreePageLocator = PageFactory.initElements(this.driver, itemAgreePageLocator.class);

    }
}
