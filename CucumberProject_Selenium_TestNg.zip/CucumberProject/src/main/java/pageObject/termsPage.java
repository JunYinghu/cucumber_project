package pageObject;

public class termsPage {
}
