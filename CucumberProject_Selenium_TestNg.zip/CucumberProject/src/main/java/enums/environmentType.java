package enums;

public enum environmentType {
    LOCAL,
    REMOTE,

}
