package enums;

public enum driverType {
    FIREFOX,
    CHROME,
    INTERNETEXPLORER
}
